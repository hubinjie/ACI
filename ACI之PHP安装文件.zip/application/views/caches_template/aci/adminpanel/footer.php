<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?><?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
</body>
</html>
