<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?><!DOCTYPE html>
<html lang="zh-CN">
<head>
	<title>一个可以使用吸心大法的框架 扩展自Codeiginter</title>
</head>
<body>