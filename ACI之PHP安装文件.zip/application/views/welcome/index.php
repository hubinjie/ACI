<?php defined('BASEPATH') or exit('No direct script access allowed.'); ?>
{template 'public','header_view'}
好吧，你现在已经拥有了吸心大法三层功力！<br/> 扩展自Codeiginter<br/> version 1.0 beta
{template 'public','footer_view'}