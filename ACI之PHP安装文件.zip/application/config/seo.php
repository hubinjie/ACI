<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['seo']['default']['title']= '';
$config['seo']['default']['keywords']= '';
$config['seo']['default']['decriptions']= '';

/* End of file seo.php */
/* Location: ./application/config/seo.php */
