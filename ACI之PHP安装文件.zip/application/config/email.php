<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.mxhichina.com';
$config['smtp_port'] = 465;
$config['smtp_user'] = 'noreply@lingdongdong.com';
$config['smtp_pass'] = '5zSH888889';
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";

$config['owner_address'] = "noreply@lingdongdong.com";