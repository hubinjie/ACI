requirejs(['jquery','aci','bootstrap'],
    function($,aci) {
        
    });